G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.2*
G04 #@! TF.CreationDate,2026-06-11T11:34:12+02:00*
G04 #@! TF.ProjectId,s3-salle-de-bain,73332d73-616c-46c6-952d-64652d626169,v3*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.2) date 2026-06-11 11:34:12*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
